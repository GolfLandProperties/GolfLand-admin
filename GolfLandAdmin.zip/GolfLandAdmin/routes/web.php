<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/admin/golfAdmin/', function () {
    return view('welcome');
});

Route::get('/admin/GolfAdminHome/', function () {
    return view('GolfAdminHome');
});
Route::post('/user/login/','userController@login');
Route::post('/user/session/',function(){
	return response()->json(["status"=>1]);
})->middleware("GFauth");
Route::post('/property/addResidential/','residential@addResidential')->middleware("GFauth");
Route::post('/property/addCommersial/','residential@addCommersial')->middleware("GFauth");
Route::post('/property/addLabour/','residential@addLabour')->middleware("GFauth");
