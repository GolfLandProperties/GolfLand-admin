function addLabourForm(id){
var tmpHtml = ''+
	'<table>'+
		'<tr>'+
			'<td><label>Property Name</label></td>'+
			'<td><input type="text" data-column ="property_name" class="form-control res_form_input"></td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Contact Name</label></td>'+
			'<td><input type="text" data-column ="property_cont_name" class="form-control res_form_input"></td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Contact Phone</label></td>'+
			'<td><input type="text" data-column ="property_cont_phone" class="form-control res_form_input"></td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Select City</label></td>'+
			'<td><div class=""><select type="select" class="form-control res_form_input" data-column ="emirates" >'+
				'<option>Abu Dhabi</option>'+
				'<option>Dubai</option>'+
				'<option>Sharjah</option>'+
				'<option>Ras Al Khaima</option>'+
				'<option>Ajman</option>'+
				'<option>Umm Al Quwain</option>'+
				'<option>Fujairah</option>'+
				'<option>Al Ain</option>'+
			'</select></div></td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Number Of Rooms</label></td>'+
			'<td><input type="text"  id="" data-column ="number_of_rooms"  class="form-control res_form_input">'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Number Of Persons</label></td>'+
			'<td><input type="text"  id="" data-column ="no_of_person"  class="form-control res_form_input">'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Common Bathroom in Every Floor</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="bathrooms" class="res_form_input"  name="commonBthroomYes" id="commonBthroomYes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="bathrooms" class="res_form_input" name="commonBthroomYes" id="commonBthroomNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Kitchen</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="kitchen" class="res_form_input"  name="kitcherYes" id="Kitchenyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="kitchen" class="res_form_input" name="kitcherYes" id="kithcenNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Launhdry</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="laundry" class="res_form_input"  name="LaunhdryYes" id="Launhdryes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="laundry" class="res_form_input" name="LaunhdryYes" id="LaunhdryNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Internet</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="internet" class="res_form_input"  name="InternetYes" id="Internetyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="internet" class="res_form_input" name="InternetYes" id="InternetNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Parking</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="parking" class="res_form_input"  name="ParkingYes" id="Parkingyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="parking" class="res_form_input" name="ParkingYes" id="ParkingNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Canteen</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="canteen" class="res_form_input"  name="CanteenYes" id="Canteenyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="canteen" class="res_form_input" name="CanteenYes" id="CanteenNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Grocery</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="Grocery" class="res_form_input"  name="GroceryYes" id="Groceryyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="Grocery" class="res_form_input" name="GroceryYes" id="GroceryNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Prayer Room</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="prayer_room" class="res_form_input"  name="prayer_roomYes" id="prayer_roomyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="prayer_room" class="res_form_input" name="prayer_roomYes" id="prayer_roomNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr>'+
			'<td><label>Water and Electricity</label></td>'+
			'<td>'+
				'<label class="radio-inline">'+
					'<input type="radio"  data-column="water_and_electricity" class="res_form_input"  name="electricity_waterYes" id="Kitchenyes" value="1" checked>Yes'+
				'</label>'+
				'<label class="radio-inline">'+
					'<input type="radio" data-column="water_and_electricity" class="res_form_input" name="electricity_waterYes" id="electricity_waterNo" value="0">No'+
				'</label>'+
			'</td>'+
		'</tr>'+
		'<tr><td colspan="2" style="text-align:center;"><button class="btn btn-primary" id="lab_add">Add</button>&nbsp;&nbsp;&nbsp;<button  id="lab_reset" class="btn btn-secondary">Reset</button> </td></tr>'+
	'</table>';
	
	$("#"+id).html(tmpHtml);
	$(document).undelegate("#lab_reset","click")
	$(document).delegate("#lab_reset","click",function(){
		addComercialForm(id)
	})
	$(document).undelegate("#lab_add","click")
	$(document).delegate("#lab_add","click",function(){
		var data = {};
		var pro = true;
		$("#"+id+" .res_form_input").each(function(ind,val){
			var type = $(this).attr("type");
			var columnKey = $(this).data("column");
			if(type == "text"){
				if($(this).val().trim()==""){
					utils.info_toaster( $(this).parents("td").siblings().children().html()+" Should Not Empty","","e" );
					pro=false;
				}
				data[ columnKey ] = $(this).val().trim();
			}else if(type == "select"){
				data[ columnKey ] = $(this).val().trim();				
			}else if(type == "radio"){
					data[ columnKey ]=$("input[name='"+$(this).attr('name')+"']:checked").val();
			}else if( type == "checkbox" ){
				if( $(this).is(':checked') ){
					data[ columnKey ]="1";
				}else{
					data[ columnKey ]="0";
				}
			}
		})
		if(pro){
			var proData = data;
			_server.post({
				url:serviceURL+"property/addLabour",
				data:{propertyData:JSON.stringify(proData)},
				success:function(response){
					if(response.status==1){
						utils.info_toaster(response.message,response.title,"s");
						addLabourForm(id)
					}else{
						utils.info_toaster(response.message,response.title,"e")
					}	
				}
			})
		}
	})
}